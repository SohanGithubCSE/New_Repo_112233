package com.rajneesh.modal;

public enum TaskStatus {
    PENDING("PENDING"),
    ASSIGNED("ASSIGNED"),
    DONE("DONE");
    TaskStatus(String done) {
    }

    void setStatus(Task task){

    }
}
