package com.rajneesh;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class hello {
    @RequestMapping("/myName")
    public String myName(){
        return "Rajneesh Verma";
    }
}
