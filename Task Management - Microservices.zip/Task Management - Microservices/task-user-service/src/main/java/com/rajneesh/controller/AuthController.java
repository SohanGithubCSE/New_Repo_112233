package com.rajneesh.controller;

import com.rajneesh.config.JwtProvider;
import com.rajneesh.modal.User;
import com.rajneesh.repository.UserRepository;
import com.rajneesh.request.LoginRequest;
import com.rajneesh.response.AuthResponse;
import com.rajneesh.service.CustomerUserServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private CustomerUserServiceImplementation customUserDetails;

    public UserRepository getUserRepository() {
        return userRepository;
    }

    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/signup")
    public ResponseEntity<AuthResponse> createUserHandler(
            @RequestBody User user) throws Exception {
        String email = user.getEmail();
        String password = user.getPassword();
        String fullName = user.getFullName();
        String role = user.getRole();
        User isEmailExist = userRepository.findByEmail(email);

        if (isEmailExist != null) {
            throw new Exception("Email Is Already Used With Another Account");
        }

        // Create new user
        User createdUser = new User();
        createdUser.setEmail(email);
        createdUser.setFullName(fullName);
        createdUser.setRole(role);
        createdUser.setPassword(passwordEncoder.encode(password));

// Save the user
        User savedUser = userRepository.save(createdUser);
// Note: The line below saving 'savedUser' again might be redundant
// userRepository.save(savedUser);

// Create authentication token (using raw password, might need adjustment depending on flow)
        Authentication authentication = new UsernamePasswordAuthenticationToken(email, password);
        SecurityContextHolder.getContext().setAuthentication(authentication);

// Generate JWT token
        String token = JwtProvider.generateToken(authentication);

// Prepare response
        AuthResponse authResponse = new AuthResponse();
        authResponse.setJwt(token);
        authResponse.setMessage("Register Success"); // Corrected from image artifact
        authResponse.setStatus(true);

// Return response entity
        return new ResponseEntity<AuthResponse>(authResponse, HttpStatus.OK);
    }

    @PostMapping("/signin")
    public ResponseEntity<AuthResponse> signin(@RequestBody LoginRequest loginRequest) {
        String username = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        System.out.println(username + " ----- " + password);

        // Assume 'authenticate' is a method defined elsewhere that returns an Authentication object[1]
        Authentication authentication = authenticate(username, password);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        String token = JwtProvider.generateToken(authentication);

        AuthResponse authResponse = new AuthResponse();
        authResponse.setMessage("Login Success");
        authResponse.setJwt(token);

        return new ResponseEntity<>(authResponse, HttpStatus.OK);
    }

    private Authentication authenticate(String username, String password) {
        // Assuming customUserDetails is an instance of UserDetailsService
        UserDetails userDetails = customUserDetails.loadUserByUsername(username);

        // System.out.println("sign in userDetails - " + userDetails); // Debug print

        if (userDetails == null) {
            // System.out.println("sign in userDetails - null " + userDetails); // Debug print
            throw new BadCredentialsException("Invalid username or password");
        }

        // Assuming passwordEncoder is an instance of PasswordEncoder
        if (!passwordEncoder.matches(password, userDetails.getPassword())) {
            // System.out.println("sign in userDetails - password not match " + userDetails); // Debug print
            throw new BadCredentialsException("Invalid username or password");
        }

        // Create and return an Authentication object for the authenticated user
        // Principal: userDetails, Credentials: null (already verified), Authorities: from userDetails
        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    }


}
