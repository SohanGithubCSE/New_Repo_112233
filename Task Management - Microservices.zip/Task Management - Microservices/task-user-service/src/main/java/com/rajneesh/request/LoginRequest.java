package com.rajneesh.request;

import jakarta.persistence.Entity; // Note: Import present but @Entity not used on class
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.servlet.config.annotation.EnableWebMvc; // Note: Import present but @EnableWebMvc not used

@Data
@AllArgsConstructor // Corrected from OCR "@LlArgsConstructor"
@NoArgsConstructor
public class LoginRequest {
    private String email;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    private String password;
}
