package com.rajneesh.config;

public class JwtConstant {
    public static final String SECRET_KEY = "jwehriksdigghgjhhsdhibjbgxzyugaesbvrqfgtavsbvvrqhfsdmrnaskeuabsdh";
    public static final String JWT_HEADER = "Authorization";

}
